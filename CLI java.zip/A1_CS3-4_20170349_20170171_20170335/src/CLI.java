import java.io.IOException;
import java.util.Scanner;

public class CLI {
	public static void main(String[] args) throws IOException {
		
		Terminal t = new Terminal();
		t.start();
	}
}
